<!DOCTYPE html>
<html lang="zxx">

<head>
    <!-- All Meta -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $profile->nama_resto ?></title>
    <!--All Css here -->
    <!--Bootstrap  css-->
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/bootstrap/css/bootstrap.min.css">
    <!-- Fontaweome css -->
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/fonts/fontawesome/css/all.css">
    <!--slick slider css -->
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/slick/slick.css">
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/slick/slick-theme.css">
    <!--nice-number css-->
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/jquery.nice-number.css">
    <!--animate css-->
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/animate.css">
    <!--meanmenu css-->
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/meanmenu.css">
    <!--magnific-popup css-->
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/magnific-popup.css">
    <!--sidebar-menu css-->
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/sidebar-menu.css">
    <!--Style css-->
    <!-- <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/style.css"> -->
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/mystyle.css">
    <!--Responsive css-->
    <link rel="stylesheet" href="<?= base_url() ?>public/assets/css/responsive.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style type="text/css">
        .ml11 {
            font-weight: 700;
            font-size: 3.5em;
        }

        .ml11 .text-wrapper {
            position: relative;
            display: inline-block;
            padding-top: 0.1em;
            padding-right: 0.05em;
            padding-bottom: 0.15em;
        }

        .ml11 .line {
            opacity: 0;
            position: absolute;
            left: 0;
            height: 100%;
            width: 3px;
            background-color: #fff;
            transform-origin: 0 50%;
        }

        .ml11 .line1 {
            top: 0;
            left: 0;
        }

        .ml11 .letter {
            display: inline-block;
            line-height: 1em;
        }
    </style>
</head>

<body>
    <!-- Start Preloader Area -->
    <!-- <div class="preloader_area">
        <div class="lodar">
            <ul>
                <li>B</li>
                <li>C</li>
            </ul>
        </div>
    </div> -->
    <!-- End Preloader Area -->
    <!-- Satrt seomun_header  -->
    <header class="seomun_header seomun_header_2 bg-dark">
        <div class="header_container_2">
            <div class="row align-items-center">
                <div class="col-lg-2">
                    <div class="seomun_logo brand_icon">
                        <a href="<?php echo base_url() ?>"><img src="<?php echo base_url(); ?>asset/img/0001-removebg-preview.png" class="img-fluid" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="seomun_menu">
                        <nav class="main_menu">
                            <ul>
                                <li><a href=""></a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="mobile_menu"></div>
                </div>
            </div>
        </div>
    </header><!-- End seomun_header  -->
    <!-- <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4"><?php echo $profile->nama_resto ?></h1>
            <p class="lead"><?php echo $profile->tentang ?></p>
        </div>
    </div> -->